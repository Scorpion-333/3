#include<stdio.h>
#include<iostream>
#include<cstdlib>
using namespace std;
int n;
typedef struct
{
	float weight;
	int parent, lchild, rchild;
	char ss;
}HTNode, * Hut;
void Select(Hut t, int k, int& s1, int& s2)
{
	int i;
	for (i = 1; i <= k && t[i].parent != 0; i++)
	{
	}
	s1 = i;
	for (i = 1; i <= k; i++)
	{
		if (t[i].parent == 0 && t[i].weight < t[s1].weight)
			s1 = i;
	}
	for (i = 1; i <= k; i++)
	{
		if (t[i].parent == 0 && i != s1)
			break;
	}
	s2 = i;
	for (int i = 1; i <= k; i++)
	{
		if (t[i].parent == 0 && t[i].weight < t[s2].weight && i != s1)
			s2 = i;
	}

}
void cread(Hut& t, float* w, char* x, int n)
{
	if (n <= 1)return;
	int m = 2 * n - 1;
	t = (Hut)malloc((m + 1) * sizeof(HTNode));

	int i = 1;
	for (i; i <= n; i++, w++, x++)
	{
		t[i].ss = *x;
		t[i].weight = *w;
		t[i].parent = 0;
		t[i].lchild = 0;
		t[i].rchild = 0;
	}
	for (; i <= m; i++)
	{
		t[i].ss = '0';
		t[i].weight = *w;
		t[i].parent = 0;
		t[i].lchild = 0;
		t[i].rchild = 0;
	}
	for (int i = n + 1; i <= m; i++)
	{
		int s1, s2;
		Select(t, i - 1, s1, s2);
		t[s1].parent = t[s2].parent = i;
		t[i].lchild = s1;
		t[i].rchild = s2;
		t[i].weight = t[s1].weight + t[s2].weight;
	}
}
void pri(Hut t)
{
	int a[10], su = 0;
	for (int i = 1; i <= n; i++)
	{
		su = 0;
		int k = i;
		int j = t[i].parent;
		while (k != 2 * n - 1)
		{
			if (t[j].lchild == k)
			{
				a[su++] = 0;
				k = j;
				j = t[k].parent;
			}
			if (t[j].rchild == k)
			{
				a[su++] = 1;
				k = j;
				j = t[k].parent;
			}
		}
		cout << "The " << t[i].ss << " 's Huffman code is:";
		for (int o = su - 1; o >= 0; o--)
			cout << a[o];
		cout << endl;
	}
}
int main()
{

	cin >> n;
	char w[100];
	cin >> w;
	float x[100];
	for (int i = 0; i < n; i++)
		cin >> x[i];
	Hut T;
	cread(T, x, w, n);

	pri(T);

}

